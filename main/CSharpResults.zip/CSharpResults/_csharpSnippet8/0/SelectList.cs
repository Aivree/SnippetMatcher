﻿using System.Web.Mvc;
using System;

namespace System.Web.Mvc
{
    public partial class SelectList
    {
        //public static System.Web.Mvc.SelectList ToSelectList<TEnum>(this TEnum enumObj)
        //{
        //    var values = from TEnum e in Enum.GetValues(typeof(TEnum))
        //                 select new { Id = e, Name = e.ToString() };
            
        //    return new System.Web.Mvc.SelectList(values, "Id", "Name", enumObj);
        //}
    }
}