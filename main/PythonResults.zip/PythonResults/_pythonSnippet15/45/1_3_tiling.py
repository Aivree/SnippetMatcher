import numpy as np

block = np.array([[4, 3], [2, 1]])
a = np.tile(block, (2, 3))

print a
