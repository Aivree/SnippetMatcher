import numpy as np
a = np.array([[1,2],[3,4]])
list(a)
print(np.arange(2,3.5,0.5))