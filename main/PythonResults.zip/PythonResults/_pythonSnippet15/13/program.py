import numpy as np
a = np.array([1,2,3,4,5])
b = 3
print "Adding numpy array with number : ",a+b
