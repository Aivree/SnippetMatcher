
import numpy as np
x = np.array([1, 2, 4, 7, 0])
np.diff(x)
#np.diff(x, n=2)
print np.diff(x)