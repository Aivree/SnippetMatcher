import numpy as np

x = np.array([1,2,3,4])
print x.size
print type(x.size)

y = np.zeros((2,3,4))
print y.size