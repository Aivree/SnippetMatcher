import numpy as np

m = np.array([[1,2,3], [4,5,6], [7,8,9]])
print(m)
"""<
[[1 2 3]
 [4 5 6]
 [7 8 9]]
>"""
v = m[1,:]
print(v)
"""<
[4 5 6]
>"""
