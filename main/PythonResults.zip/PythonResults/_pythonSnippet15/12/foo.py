

import numpy as np
from pylab import *




def f(x):
    x+=x



a = np.array([1,2])
f(a)
