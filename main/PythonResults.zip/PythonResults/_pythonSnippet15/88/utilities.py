__author__ = 'arkilic'

import numpy as np

def import_image():
    pass


def convert_to_npArray():
    pass