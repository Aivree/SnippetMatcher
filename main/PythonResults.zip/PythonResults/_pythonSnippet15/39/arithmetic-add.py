import numpy as np

x = np.array([1.0,2.0,3.0])
y = np.array([9.0,7.0,5.0])
z = x + y
print z
print z[0]
print z[1]
print z[2]
