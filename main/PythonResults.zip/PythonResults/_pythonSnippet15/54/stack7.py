import numpy as np

x = np.array([[4, 5, 7]])
print x.shape # (1, 3)
print x.T.shape # (3, 1)
print np.transpose(x).shape # (3, 1)




