import numpy as np

npA = np.arange(1, 10000001, 1)

print 'AMount of numbers in array: {:,}'.format(npA.size)


