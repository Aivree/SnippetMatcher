import numpy as np

A = np.array([[1, 1], [1, 1]], dtype='float')
print A / 2
