import numpy as np

x = np.array([1,2,3])
y = np.array([9,7,5])
print x - y
z = x - y
print z[0]
print z[1]
print z[2]
