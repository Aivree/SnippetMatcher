import numpy as np

x = np.array([1,2,3])
print x

y = np.array([1,2,3])
z = np.array([4])

print np.dot(x,y)

print np.dot(x,z)