from logreg import Logreg
from numpy.random import randn
import numpy as np

X = randn(5, 10)
Y = np.array([[1,0],[1,0], [1,0],[1,0],[1,0],\
        [0,1],[0,1],[0,1],[0,1],[0,1]])


