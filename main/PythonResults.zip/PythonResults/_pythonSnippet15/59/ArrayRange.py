import numpy as np

npA = np.arange(1.0, 20.0, 0.05)

print 'AMount of numbers in array:',npA.size
print npA

