import numpy as np

x = np.array([1.0,2.0,3.0])
y = np.array([9,7,5])
print x / y
z = x / y
print z[0]
print z[1]
print z[2]

print x / 3