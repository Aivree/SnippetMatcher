import numpy as np

a = np.array([0, 1, 0])
b = np.array([[1, -4, -4], [0, -11, -1]])
print np.abs(b)
