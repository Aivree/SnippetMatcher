import numpy as np

v = np.array([2 * i for i in range(5)])
print(v)
"""<
[0 2 4 6 8]
>"""
