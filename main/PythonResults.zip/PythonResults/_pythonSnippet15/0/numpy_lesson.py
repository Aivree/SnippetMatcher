import numpy as np

t = [1, 2, 3]
a1 = np.array(t)
