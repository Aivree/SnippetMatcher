import numpy as np
square = np.array([[5, 6], [7, 8]])
print square[ [1] ]
