#!/usr/bin/python2

import numpy as np

array = np.load("lobSTRsave.npy", "r+")
print array
