import numpy as np

m = np.array([[1,2,3], [4,5,6]])
print(m)
"""<
[[1 2 3]
 [4 5 6]]
>"""
v = m.flatten()
print(v)
"""<
[1 2 3 4 5 6]
>"""
