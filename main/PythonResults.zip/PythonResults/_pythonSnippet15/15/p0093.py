import numpy as np

v = np.array([1,2,3,4]).reshape(-1,1)
print(v)
"""<
[[1][2][3][4]]
>"""
