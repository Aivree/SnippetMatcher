'''
Created on 04.04.2012

@author: Axel
'''
from numpy import zeros
import numpy as np
y = zeros(3)
np.array(y)
