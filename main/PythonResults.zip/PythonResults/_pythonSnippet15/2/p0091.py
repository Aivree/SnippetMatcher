import numpy as np

m = np.array([[1,2,3], [3,4,5]])
print(m)
"""<
[[1 2 3]
 [3 4 5]]
>"""
