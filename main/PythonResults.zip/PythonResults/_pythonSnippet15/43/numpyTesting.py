import numpy as np
a = np.array([[1, 0, 1], [1, 1, 1], [0, 0, 1]], dtype=bool)
b = np.array([[1, 0, 1], [1, 1, 0], [0, 0, 1]])
print a.dot(b)


