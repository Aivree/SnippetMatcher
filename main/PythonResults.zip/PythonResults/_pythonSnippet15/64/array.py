import numpy as np

a = np.array([1, 2, 3, 4])
b = np.array([[1, 2], [3, 4]])
c = np.zeros((5, 5))
d = np.arange(0,4).reshape(2,2)
e = np.ndarray((10, 10, 100), dtype='float')
f = np.array(e)
g = np.ones_like(d)

