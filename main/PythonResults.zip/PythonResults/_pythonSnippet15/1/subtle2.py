import numpy as np

A = np.array([[1, 1], [1, 1]])
print A / 2
