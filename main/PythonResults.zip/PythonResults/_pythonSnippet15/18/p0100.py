import numpy as np

v = np.array([1,2,3,4,5,6])
print(v)
"""<
[1 2 3 4 5 6]
>"""
m = v.reshape(3,2)
print(m)
"""<
[[1 2]
 [3 4]
 [5 6]]
>"""
